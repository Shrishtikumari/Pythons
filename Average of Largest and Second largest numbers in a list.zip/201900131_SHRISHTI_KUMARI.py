"""
   Name: Shrishti Kumari
   Registration no: 201900131
   Description: To demonstarte a program to implement a Python program to find the average of 
                              largest and second largest number in a list. Without using inbuilt functions to identify
                              largest in the list.
   Date: 27/01/2021
   
   Algorithm:
       
       Algorithm Description: This algorithm is all about how we implement a Python program to find the average of 
                              largest and second largest number in a list. Without using inbuilt functions to identify
                              largest in the list.
       Input Variable: items_list
       Output Variable: items_list
   1.Start
   2.Display "=============IMPLEMENTING AVERAGE PROGRAM=============="
   3.Initialize items_list=[1,4,2,9,8,7,3]
   4.Initailize n<-7 which is equal to the length of the items_list
   5.Display "=>Items in the list are:"
   6.Until for i in range 0 to n-1
     6.1 Display items_list[i] values
   7.Until for i in range 0 to n-1
     7.1 Until for j in range 0 to n-2
         7.1.1 Check if(items_list[j]<=items_list[j+1]) otherwise go to else part.
               1.t->items_list[j]
               2.items_list[j]->items_list[j+1]
               3.items_list[j+1]->t
         7.1.2 In else part continue with the loops
   8.Display "=>Elements after sorting:"
   9.Until for i in range 0 to n-1
     9.1 Display items_list[i] values
  10.Display "=>Largest element:" and items_list[0] value
  11.Display "=>Second largest element:" and items_list[1] value
  12.[Compute]  Avg<-(items_list[0]+items_list[1])/2 
  13.Display "=>Average: " and Avg value
  14.Stop
         

INPUTS / OUTPUTS

=============IMPLEMENTING AVERAGE PROGRAM==============

=>Items in the list are: 
1 	4 	2 	9 	8 	7 	3 	

=>Elements after sorting:
9 	8 	7 	4 	3 	2 	1 	

=>Largest element: 9
=>Second largest element: 8

=>Average:  8.5

"""

print("\n=============IMPLEMENTING AVERAGE PROGRAM==============\n")
items_list=[1,4,2,9,8,7,3] #Initializing list elements.
n=7 #It is equal to the length of the items_list

print("=>Items in the list are: ")

#For displaying all the elements in the list.
for i in range(n):
    print(items_list[i],"\t",end="")
  
#These steps has been made to perform bubble sort to arrange it in order descending order.
for i in range(n):
    for j in range(n-1):
        if(items_list[j]<=items_list[j+1]):
            
            t=items_list[j] #Computing
            items_list[j]=items_list[j+1]
            items_list[j+1]=t #Computing
            
        else:
            continue #Otherwise continue to the loop
        
print("\n\n=>Elements after sorting:")

#This for loop if for displaying elements after sorting it will run till n
for i in range(n):
    print(items_list[i],"\t",end="") #Displaying

#Printing largest and second largest element
print("\n\n=>Largest element:",items_list[0])
print("=>Second largest element:",items_list[1])

Avg=(items_list[0]+items_list[1])/2 #Performing calculation
print("\n=>Average: ",Avg) #Displaying average	 	  	 	  	 	   	        	 	
