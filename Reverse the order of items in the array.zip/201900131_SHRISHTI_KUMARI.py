"""
  Name: Shrishti Kumari
  Registration no: 201900131
  Description: To demonstrate a Python program to reverse the order of the items in the array without 
               using any built-in function.
  Date: 27/01/2021
  
  Algorithm:
      
      Algorithm description: This algorithm is all about how we implement a Python program to reverse 
                             the order of the items in the array without using any built-in function.
      Input Variables: item_list
      Output Variables: item_list
          
  1.Start
  2.Display "=============IMPLEMENTING REVERSE ORDER============"
  3.Initializing item_list=[1,2,3,4,5,6,7]
  4.i->0
  5.j->7
  6.Display "=>Elements before reversing the list:"
  7.Until for i in range(j)
    7.1 Display "item_list[i]" value
  8.Display "=>Elements after reversing the list:"
  9.Until for i in range(j)
    9.1 Display "item_list[j-1]" value
    9.2 j=j-1
 11.Display "================XXXXXXXXXXXXXXXXXX=================="
 12.Stop
  
INPUTS / OUTPUTS

=============IMPLEMENTING REVERSE ORDER============

=>Elements before reversing the list:

1 	2 	3 	4 	5 	6 	7 	

=>Elements after reversing the list:

7 	6 	5 	4 	3 	2 	1 	

================XXXXXXXXXXXXXXXXXX==================


"""

print("\n=============IMPLEMENTING REVERSE ORDER============\n")
item_list=[1,2,3,4,5,6,7] #Initiaizing the list.
i=0 #Initializing
j=7 #Initializing

print("=>Elements before reversing the list:\n")
for i in range(j): #until condition terminates
    print(item_list[i],"\t",end="")

print("\n\n=>Elements after reversing the list:\n")

for i in range(j): #until condition terminates
    print(item_list[j-1],"\t",end="")
    j=j-1 #Decrementing by 1
print("\n\n================XXXXXXXXXXXXXXXXXX==================")    
    
    	 	  	 	  	 	   	        	 	
