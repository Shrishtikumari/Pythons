
"""
   Name: Shrishti Kumari
   Registration no: 201900131
   Description: To demonstarte a program to implement a Python program to display the Fibonacci sequence upto n terms.
   Date: 27/01/2021
   
   Algorithm:
       Algorithm Description: This algorithm is all about how we implement a Python program to display the Fibonacci sequence upto n terms.
       Input Variable: r
       Output Variable: n1,n2,n3
       
   1.Start
   2.Constructing a infinite loop while(1) which will not terminate until you will terminated.
   3.Display "=============IMPLEMENTING FIBONACCI SERIES============="
   4.Display "=>Enter a number till which you want fibonacci series: " and read r.
   5.Check if(r<=0)
     5.1 Display "Invalid number!"
   6.In else part
     6.1 Display "=>Fibonacci series is:"
     6.2 n1->0
     6.3 n2->1
     6.4 Display n1 and n2
     6.7 Until for i in range(2,r)
         6.7.1 n3<-n1+n2
         6.7.2 Display n3
         6.7.3 n1<-n2
         6.7.4 n2<-n3
     6.8 Display "Want to Continue(Yes=1/ No=0)?: " and read choice.
     6.9 Check if(choice==0)
         6.9.1 Display "Thank You!"
         6.9.2 sys.exit(0)
     6.10 Display "----------------------------------------------------------"
   7.Stop
        
        
INPUTS / OUTPUTS


=============IMPLEMENTING FIBONACCI SERIES=============

=>Enter a number till which you want fibonacci series: 7

=>Fibonacci series is:
0 	 1 	1 	2 	3 	5 	8 	

Want to Continue(Yes=1/ No=0)?: 1
----------------------------------------------------------------------


=============IMPLEMENTING FIBONACCI SERIES=============

=>Enter a number till which you want fibonacci series: 5

=>Fibonacci series is:
0 	 1 	1 	2 	3 	

Want to Continue(Yes=1/ No=0)?: 0
Thank You!


"""
import sys #For using function sys.exit(0)

#Constructing while loop which will run infinitesly until it get terminated.
while(1):
    print("\n=============IMPLEMENTING FIBONACCI SERIES=============\n")
    r=int(input("=>Enter a number till which you want fibonacci series: "))
    
    #Checking conditions
    if(r<=0):
        print("Invalid number!")
    else:
        print("\n=>Fibonacci series is:")
        n1=0 #Initializing
        n2=1 #Initializing
        print(n1,"\t",n2,"\t",end="")
        
        for i in range(2,r):#Constructing for loop 
            n3=n1+n2 #Computing
            print(n3,"\t",end="")
            n1=n2 #Initializing
            n2=n3 #Initializing
            
    choice=int(input("\n\nWant to Continue(Yes=1/ No=0)?: ")) #Reading user choice
    if(choice==0):
        print("Thank You!")
        sys.exit(0) #Exiting
    print("----------------------------------------------------------------------\n")
       

	 	  	 	  	 	   	        	 	
